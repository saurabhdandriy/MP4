import { Component , OnInit} from '@angular/core';
import { Employee } from './employee';
@Component({
  selector: 'my-app',
  templateUrl:'./component.html'
})
export class AppComponent 
 { 
    employees:Employee[]=[
	
    {empId:1001,empName:"Shilpa",empSalary:13361,empDepartment:"JEE",empjoiningdate:'06/12/2000'},
	{empId:1002,empName:"Monu",empSalary:13361,empDepartment:"VnV",empjoiningdate:'06/12/2000'},
	{empId:1003,empName:"Vidya",empSalary:13361,empDepartment:".Net",empjoiningdate:'06/12/2000'},
	{empId:1004,empName:"Saurabh",empSalary:13361,empDepartment:"BI",empjoiningdate:'06/12/2000'},
	{empId:1005,empName:"Bala",empSalary:13361,empDepartment:"JEE",empjoiningdate:'06/12/2000'}
	
    ];
	myFunc():void
	{
		console.log("inside function");
		this.employees.sort(function (name1,name2)
		{
			
			if(name1.empName < name2.empName)
			{
				return -1;
			}
			else if(name1.empName > name2.empName)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		});
		
	}
 }
