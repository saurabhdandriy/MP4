"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        this.employees = [
            { empId: 1001, empName: "Shilpa", empSalary: 13361, empDepartment: "JEE", empjoiningdate: '06/12/2000' },
            { empId: 1002, empName: "Monu", empSalary: 13361, empDepartment: "VnV", empjoiningdate: '06/12/2000' },
            { empId: 1003, empName: "Vidya", empSalary: 13361, empDepartment: ".Net", empjoiningdate: '06/12/2000' },
            { empId: 1004, empName: "Saurabh", empSalary: 13361, empDepartment: "BI", empjoiningdate: '06/12/2000' },
            { empId: 1005, empName: "Bala", empSalary: 13361, empDepartment: "JEE", empjoiningdate: '06/12/2000' }
        ];
    }
    AppComponent.prototype.myFunc = function () {
        console.log("inside function");
        this.employees.sort(function (name1, name2) {
            if (name1.empName < name2.empName) {
                return -1;
            }
            else if (name1.empName > name2.empName) {
                return 1;
            }
            else {
                return 0;
            }
        });
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: './component.html'
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map