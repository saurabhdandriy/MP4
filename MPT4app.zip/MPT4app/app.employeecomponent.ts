
import {Component} from '@angular/core';

import {EmployeeList} from './app.employeelist';


@Component({
	
	selector:'<my-component></my-component>',
	templateUrl:'./app.employeecomponent.html'
	
	
})

export class AppEmployeeComponent
{
	empId:number;
	empName:string;
	empSalary:number;
	empDepartment:string;
	
	empId2:number;
	empName2:string;
	empSalary2:number;
	empDepartment2:string;
	
	employees:EmployeeList[] = [];

	addDetails():void
	{
		if(this.empId != null && this.empName != null && this.empSalary != null && this.empDepartment != null)
		{
			let emp:EmployeeList = {empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDepartment:this.empDepartment}; 
			this.employees.push(emp);
			this.clearAll();
		}
		else
		{
			alert("Insert all fields")
		}
	}
	
	
	putData(empId:number, empName:string, empSalary:number,empDepartment:string):void
	{
		
		this.empId2=empId;
		this.empName2=empName;
		this.empSalary2=empSalary;
		this.empDepartment2=empDepartment;
		
	}
	
	 
	//Update Record
	
	updateData():void
	{
		if(this.empId2 != 0)
		{
			let obj:EmployeeList=null;
			for(obj of this.employees)
			{
				if(obj.empId==this.empId2)
				{
					
					break;
				}
				
			}			
			obj.empName=this.empName2;
			obj.empSalary=this.empSalary2;
			obj.empDepartment=this.empDepartment2;
			this.clearAll();
		}
		else
		{
			console.log("error");
		}
		
	}
	
	
	delete(emp:EmployeeList):void
	{
		console.log("Shilpa");
		console.log(emp);
		var index = this.employees.indexOf(emp);
		console.log(index);
		this.employees.splice(index); 
        this.clearAll();		
	}
	
	myFunc1():void
	{
		this.employees.sort(function (name1,name2)
		{
			if(parseInt(name1.empId)< parseInt(name2.empId) )
			{
				return -1;
			}
			else if(parseInt(name1.empId) > parseInt(name2.empId))
			{
				return 1;
			}
			else
			{
				return 0;
			}
		});
		
	}
	
	myFunc2():void
	{
		
		this.employees.sort(function (name1,name2)
		{
			
			if(name1.empName.toLowerCase() < name2.empName.toLowerCase() )
			{
				return -1;
			}
			else if(name1.empName.toLowerCase() > name2.empName.toLowerCase())
			{
				return 1;
			}
			else
			{
				return 0;
			}
		});
		
	}
	
	myFunc3():void
	{
		this.employees.sort(function (name1,name2)
		{
			
			if(parseInt(name1.empSalary) < parseInt(name2.empSalary) )
			{
				console.log(name1.empSalary);
				return -1;
			}
			else if(parseInt(name1.empSalary) >parseInt(name2.empSalary))
			{
				return 1;
			}
			else
			{
				return 0;
			}
		});
		
	}
	
	myFunc4():void
	{
		this.employees.sort(function (name1,name2)
		{
			
			if(name1.empDepartment.toLowerCase() < name2.empDepartment.toLowerCase() )
			{
				return -1;
			}
			else if(name1.empDepartment.toLowerCase() > name2.empDepartment.toLowerCase())
			{
				return 1;
			}
			else
			{
				return 0;
			}
		});
		
	}
	
	clearAll():void{
		this.empId=null;
		this.empName=null;
		this.empSalary=null;
		this.empDepartment=null;
		this.empId2=null;
		this.empName2=null;
		this.empSalary2=null;
		this.empDepartment2=null;
	}
}