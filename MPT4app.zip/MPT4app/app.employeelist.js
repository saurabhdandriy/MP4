//import { Component } from '@angular/core';
"use strict";
var EmployeeList = (function () {
    function EmployeeList() {
    }
    return EmployeeList;
}());
exports.EmployeeList = EmployeeList;
//# sourceMappingURL=app.employeelist.js.map